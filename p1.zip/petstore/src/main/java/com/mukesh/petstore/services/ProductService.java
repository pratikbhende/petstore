package com.mukesh.petstore.services;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.mukesh.petstore.dtos.AddProductDto;
import com.mukesh.petstore.dtos.UpdateProductDto;
import com.mukesh.petstore.entities.Product;
import com.mukesh.petstore.repository.ProductRepository;

@Service
public class ProductService {
	
	//private Map<Integer , Product> products = new HashMap<>();
//	private AtomicInteger counter = new AtomicInteger();
	// atomicInteger increment the counter  every time we call.
	
	@Autowired
	private ProductRepository productRepository;
	
	public Product createProduct(AddProductDto addProductDto) {
		Product product = new Product();
		
	//	product.setId(counter.incrementAndGet());
		product.setProductName(addProductDto.getProductName());
		product.setManufacturingDate(addProductDto.getManufacturingDate());
		product.setManufacturer(addProductDto.getManufacturer());
		product.setPrice(addProductDto.getPrice());
		product.setDiscription(addProductDto.getDiscription());
		product.setImgUrl(addProductDto.getImgUrl());
		
		//products.put(product.getId(), product);
		
		
		this.productRepository.save(product);
		return product;
		
	}
	
	public Collection<Product> getAllProduct(){
		//return this.products.values();
		return this.productRepository.findAll();
	}
	
	public Product getProductById(Integer id) {
		//Product product = this.products.get(id);
		
	Product product = this.productRepository.findById(id).orElse(null);	
	
		if(product == null) {
			throw new ResponseStatusException( HttpStatus.NOT_FOUND , "Product not found");
		}else {
			return product;
		}
	}
		
	public void deleteProduct(Integer id) {
		
		Product product = this.getProductById(id);
		
		if(product == null) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Product not found");
		}else {
			//products.remove(id);
			this.productRepository.delete(product);
		}
		
	}
	
	public Product updateProduct(Integer id , UpdateProductDto updateProductDto) {
		
		Product product = getProductById(id);
		
		if(updateProductDto.getProductName() != null) {
			product.setProductName(updateProductDto.getProductName());
		}
		if(updateProductDto.getManufacturingDate()!= null) {
			product.setManufacturingDate(updateProductDto.getManufacturingDate());
		}
		if(updateProductDto.getManufacturer()!= null) {
			product.setManufacturer(updateProductDto.getManufacturer());
		}
		if(updateProductDto.getPrice()!= null) {
			product.setPrice(updateProductDto.getPrice());
		}
		if(updateProductDto.getDiscription()!= null) {
			product.setDiscription(updateProductDto.getDiscription());
		}
		if(updateProductDto.getImgUrl()!= null) {
			product.setImgUrl(updateProductDto.getImgUrl());
		}
		
		this.productRepository.save(product);
		return product;
	}
	
	public List<Product> getBymanufacturer(String manufacturer){
		return this.productRepository.findBymanufacturer(manufacturer);
	}
	
	public List<Product> getByPriceLessThan(Double price){
		return this.productRepository.findByPriceLessThan(price);
	}
	
}
