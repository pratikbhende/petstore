package com.mukesh.petstore.validator;

import org.springframework.beans.BeanWrapperImpl;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class ConfirmPasswordValidator implements ConstraintValidator<VerifyPassword, Object> {
private String field;
private String matchingField;
	
	@Override
	public void initialize(VerifyPassword constraintAnnotation) {
		this.field = constraintAnnotation.field();
		this.matchingField = constraintAnnotation.matchingField();
	}
	
	
	
	@Override
	public boolean isValid(Object value, ConstraintValidatorContext context) {
		
		Object fieldvalue = new BeanWrapperImpl(value).getPropertyValue(field);
		Object matchingfieldvalue = new BeanWrapperImpl(value).getPropertyValue(matchingField);
	
		if(fieldvalue != null) {
			return fieldvalue.equals(matchingfieldvalue);
		}
	 return matchingfieldvalue != null;
	}

}
