package com.mukesh.petstore.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mukesh.petstore.entities.User;

public interface UserRepository extends JpaRepository<User, Integer> {

}
