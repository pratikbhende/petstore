package com.mukesh.petstore.services;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import com.mukesh.petstore.dtos.RegisterUserDto;
import com.mukesh.petstore.dtos.UpdateUserDto;
import com.mukesh.petstore.entities.User;
import com.mukesh.petstore.repository.UserRepository;

@Service
public class AuthService {
	
	private Map<Integer, User> users = new HashMap<>();
//	private AtomicInteger counter = new AtomicInteger();
	
	@Autowired
	private UserRepository userRepository;
	
	public User registerUser(RegisterUserDto registerUserDto){
		
		User user = new User();
		
		
//		user.setId(counter.incrementAndGet());
		
		 
		user.setFirst_name(registerUserDto.getFirst_name());
		user.setLast_name(registerUserDto.getLast_name());
		user.setEmail(registerUserDto.getEmail());
		user.setPassword(registerUserDto.getEmail());
		user.setPassword(registerUserDto.getPassword());
		user.setConfirmPassword(registerUserDto.getConfirmPassword());
		user.setMobile(registerUserDto.getMobile());
		
//		users.put(user.getId(), user);
		this.userRepository.save(user);
		
		return user;
	}
	
	public Collection<User> getAllUsers(){
//		return this.users.values();
		return this.userRepository.findAll();
	}

	public User getUserById(Integer id) {
//		User user = this.users.get(id);
		User user = this.userRepository.findById(id).orElse(null);
		
		if(user == null) {
			throw new ResponseStatusException( HttpStatus.NOT_FOUND , "User not found");
		}else {
		
		return user;
		}
	}
	
	public void deletUserById(Integer id) {
		User user = this.getUserById(id);
		
		if(user == null) {
			throw new ResponseStatusException(HttpStatus.NOT_FOUND , " User not found");
		}else {
//			users.remove(id);
			this.userRepository.delete(user);
		}
	}
	
	public User updateUser(Integer id, UpdateUserDto updateUserDto ) {
		User user = getUserById(id);
		
		if(updateUserDto.getFirst_name() != null) {
			user.setFirst_name(updateUserDto.getFirst_name());
		}
		if(updateUserDto.getLast_name()!=null) {
			user.setLast_name(updateUserDto.getLast_name());
		}
		if(updateUserDto.getEmail()!=null) {
			user.setEmail(updateUserDto.getEmail());
		}
		if(updateUserDto.getPassword()!=null) {
			user.setPassword(updateUserDto.getPassword());
		}
		if(updateUserDto.getConfirmPassword()!=null) {
			user.setConfirmPassword(updateUserDto.getConfirmPassword());
		}
		if(updateUserDto.getMobile()!=null) {
			user.setMobile(updateUserDto.getMobile());
		}
		this.userRepository.save(user);
		return user;
	}
	
}
