package com.mukesh.petstore.dtos;



import com.mukesh.petstore.validator.PhoneNumber;
import com.mukesh.petstore.validator.VerifyPassword;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
@VerifyPassword(field = "password", matchingField = "confirmPassword")
public class RegisterUserDto {
	
	@NotNull
	@Size(min = 3 , message = "First name should be more than 3 characters")
	private String first_name;
	@NotNull
	@Size(min = 3 , message = "First name should be more than 3 characters")
	private String last_name;
	@NotNull
	@Email
	private String email;
	@NotNull
	@Pattern(regexp="[a-zA-Z0-9]+" , message = "Password should only contain alphabets and digits")
	private String password;
	
	private String confirmPassword;
	@PhoneNumber
	private String mobile;
	
}
