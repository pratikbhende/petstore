package com.mukesh.petstore.dtos;

import java.time.Instant;

import lombok.Data;

@Data 
public class UpdateProductDto {

	private String productName;
	private Instant manufacturingDate;
	private String manufacturer;
	private Double price;
	private String discription;
	private String imgUrl;
}
