package com.mukesh.petstore.controller; 

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mukesh.petstore.dtos.AddProductDto;
import com.mukesh.petstore.dtos.UpdateProductDto;
import com.mukesh.petstore.services.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping("")
	public ResponseEntity<?> create(@RequestBody AddProductDto addProductDto){
		// request body convert JSON format to object and store it in productDto
		return ResponseEntity.ok(this.productService.createProduct(addProductDto));
		// response entity gives status , headers(meta data) , actual data
	}
	@GetMapping("")
	public ResponseEntity<?> getAll(){
		return ResponseEntity.ok(this.productService.getAllProduct());
	}
	
	@GetMapping("{id}")
	public ResponseEntity<?> getById(@PathVariable Integer id){
		  // pathVariable get id from {id} from url 
		return ResponseEntity.ok(this.productService.getProductById(id));
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<?> delete(@PathVariable Integer id){
		this.productService.deleteProduct(id);
		
		return ResponseEntity.noContent().build();
	}
	
	@PutMapping("{id}")
	public ResponseEntity<?> update(@PathVariable Integer id , @RequestBody UpdateProductDto updateProductDto){
		return ResponseEntity.ok(this.productService.updateProduct(id, updateProductDto));
	}

	@GetMapping("/search/findbymanufacturer")
	public ResponseEntity<?> getByManufacturer(@RequestParam String manufacturer){
		return ResponseEntity.ok(this.productService.getBymanufacturer(manufacturer));
	}
	
	@GetMapping("/search/findbyprice")
	public ResponseEntity<?> getByPriceLessThan(Double price){
		return ResponseEntity.ok(this.productService.getByPriceLessThan(price));
	}
}
