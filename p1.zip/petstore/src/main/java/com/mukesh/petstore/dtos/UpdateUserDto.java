package com.mukesh.petstore.dtos;

import com.mukesh.petstore.validator.PhoneNumber;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UpdateUserDto {
	

	@Size(min = 3 , message ="first_name should have more than 3 characters")
	private String first_name;
	
	@Size(min = 3, message = "last_name should have more than 3 characters")
	private String last_name;
	private String email;
	
	
	@Pattern(regexp = "[a-zA-Z0-9]+" , message = "Password should contain characters and digits only")
	private String password;
	private String confirmPassword;
	@PhoneNumber
	private String mobile;
}
