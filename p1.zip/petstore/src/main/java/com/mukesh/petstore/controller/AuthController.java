package com.mukesh.petstore.controller;

import org.apache.catalina.connector.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mukesh.petstore.dtos.RegisterUserDto;
import com.mukesh.petstore.dtos.UpdateUserDto;
import com.mukesh.petstore.services.AuthService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
public class AuthController {
	
	@Autowired
	private AuthService authService;
	
	
	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody @Valid RegisterUserDto registerUserDto){
		return ResponseEntity.ok(this.authService.registerUser(registerUserDto));
		
	}
	
	@GetMapping("")
	public ResponseEntity<?> getAll(){
		return ResponseEntity.ok(this.authService.getAllUsers());
	}
	
	@GetMapping("{id}")
	public ResponseEntity<?> getById(@PathVariable Integer id){
		return ResponseEntity.ok(this.authService.getUserById(id));
	}
	
	@DeleteMapping("{id}")
	public ResponseEntity<?> deleteUser(@PathVariable Integer id){
		this.authService.deletUserById(id);
		return ResponseEntity.noContent().build();
	}
	
	@PutMapping("{id}")
	public ResponseEntity<?> updateUserByid(@PathVariable Integer id ,@RequestBody @Valid   UpdateUserDto updateUserDto){
		return ResponseEntity.ok(this.authService.updateUser(id, updateUserDto));
	}
	
	
	
}
